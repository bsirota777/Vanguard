package com.vanguard;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.vanguard.creator.impl.CSVOutputCreator;
import com.vanguard.parsers.impl.XMLFileParser;

@SpringBootApplication
public class TradeReportingEngine implements CommandLineRunner {

    private static Logger LOG = LoggerFactory
      .getLogger(TradeReportingEngine.class);
    
	@Autowired
	private XMLFileParser fileParser;
	
	@Autowired
	private CSVOutputCreator outputCreator;

    public static void main(String[] args) {
        SpringApplication.run(TradeReportingEngine.class, args);
    }
 
    @Override
    public void run(String... args) {
 
        if (args.length == 1) {
        	
        	String directory = args[0];
        	
        	List<List<String>> data = fileParser.parse(directory);
        	
        	if (data.size() > 0) {
        		outputCreator.generate(data, System.out);
        	}
        	
        } else {
        	System.out.println("Please provide a parameter for source file directory path.");
        }
    }
}