package com.vanguard.creator;

import java.io.PrintStream;
import java.util.List;

public interface OutputCreator {

	void generate(List<List<String>> outputList, PrintStream printStream);
}
