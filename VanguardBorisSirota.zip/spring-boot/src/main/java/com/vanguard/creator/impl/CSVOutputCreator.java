package com.vanguard.creator.impl;

import java.io.PrintStream;
import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.vanguard.creator.OutputCreator;

@Component
public class CSVOutputCreator implements OutputCreator {
	
	private static final String BUYER_PARTY = "//buyerPartyReference/@href";
	private static final String SELLER_PARTY = "//sellerPartyReference/@href";
	private static final String PREMIUM_AMOUNT = "//paymentAmount/amount";
	private static final String PREMIUM_CURRENCY = "//paymentAmount/currency";
	
	private static final char COLUMN_SEPARATOR = ',';
	
	@Autowired
    private Environment env;
	
	/**
	 * <p>Generates and writes to Standard output data in table format.
	 * </p>
	 * @param outputList ordered data in table format
	 * @return none
	 */
	public void generate(List<List<String>> outputList, PrintStream printStream) {
		
		// Process headers
		String buyerPartyHeader = env.getProperty(BUYER_PARTY);
    	String sellerPartyHeader = env.getProperty(SELLER_PARTY);
    	String premiumAmountHeader = env.getProperty(PREMIUM_AMOUNT);
    	String premiumCurrencyHeader = env.getProperty(PREMIUM_CURRENCY);
    	
		StringBuilder header = new StringBuilder();
		header.append(buyerPartyHeader);
		header.append(COLUMN_SEPARATOR);
		header.append(sellerPartyHeader);
		header.append(COLUMN_SEPARATOR);
		
		header.append(premiumAmountHeader);
		header.append(COLUMN_SEPARATOR);
		header.append(premiumCurrencyHeader);
		
		printStream.println(header.toString());
		
		if (outputList != null) {
			// Process rows
			for (List<String> row : outputList) {
				StringBuilder rowOutput = new StringBuilder();
				ListIterator<String> rowItr = row.listIterator();
				while (rowItr.hasNext()) {
				    String field = rowItr.next();
					rowOutput.append(field);
					if (rowItr.hasNext()) {
					    rowOutput.append(COLUMN_SEPARATOR);
					}
				}
				printStream.println(rowOutput);
			}
		}
	}

}
