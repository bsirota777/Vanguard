package com.vanguard.parsers;

import java.util.List;

public interface FileParser {

	List<List<String>> parse(String directoryPath);
}
