package com.vanguard.parsers.impl;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.vanguard.parsers.FileParser;

@Component
@PropertySource("classpath:filters.properties")
public class XMLFileParser implements FileParser {
	
	private static Logger LOG = LoggerFactory.getLogger(XMLFileParser.class);
	
	private static final String BUYER_PARTY = "//buyerPartyReference/@href";
	private static final String SELLER_PARTY = "//sellerPartyReference/@href";
	private static final String PREMIUM_AMOUNT = "//paymentAmount/amount";
	private static final String PREMIUM_CURRENCY = "//paymentAmount/currency";
	
	private static final String EMU_BANK = "EMU_BANK";
	private static final String AUD_CURRENCY = "AUD";
	private static final String USD_CURRENCY = "USD";
	private static final String BISON_BANK = "BISON_BANK";

	/**
	 * <p>Reads in XML files from the path specified, parses those, applies business rules and converts to a List of Lists that can be used for further processing.
	 * </p>
	 * @param directoryPath file path that contains input XML files
	 * @return ordered list of lists that represents a table of data fields.
	 */
	public List<List<String>> parse(String directoryPath) {	
		
		List<List<String>> outputList = new ArrayList<List<String>>();
		
		if (directoryPath != null && directoryPath.length() > 0) {
		
			File dir = new File(directoryPath);
			File[] directoryListing = dir.listFiles();
			if (directoryListing != null) {
				
			    for (File file : directoryListing) {
			    	LOG.info("Processing File: "+file.getName());
			    	
			    	List<String> data = getDataValues(file);
			    	// Check if data has been extracted after applying business rules.
			    	if (data != null && data.size() > 0) {
			    	    outputList.add(data);
			    	}
			    }
			} else {
			    LOG.error("Could not parse directory for files");
			}
		}
		  
		return outputList;
	}
	
	/**
	 * <p>Extracts data values from the file provided based on business rules.
	 * </p>
	 * @param outputList ordered data in table format
	 * @return dataValues list of Strings that match business rules
	 */
	public List<String> getDataValues(File file) {
		
		List<String> dataValues = new ArrayList<String>();
		
		try {
			FileInputStream fileIS = new FileInputStream(file);
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			Document xmlDocument = builder.parse(fileIS);
			
			XPath xPath = XPathFactory.newInstance().newXPath();
			
			String expression = BUYER_PARTY;
			
			NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODESET);
			
			// Extract data, check if it is available
			if (nodeList.getLength() > 0) {

	            Node nNode = nodeList.item(0);
	            
	            String buyer = nNode.getNodeValue();
	            
	            if (buyer == null) {
	            	return dataValues;
	            }
 
	            expression = SELLER_PARTY;
	            
	            nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODESET);
				
				if (nodeList.getLength() > 0) {

		            nNode = nodeList.item(0);
		            
		            String seller = nNode.getNodeValue();
		            
		            if (seller == null) {
		            	return dataValues;
		            }
		            
		            if (!areAnagrams(buyer,seller)) {
		            	expression = PREMIUM_CURRENCY;
			            
			            nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODE);
						
						if (nodeList.getLength() > 0) {

				            nNode = nodeList.item(0);
				            
				            String currency = nNode.getNodeValue();
				            
				            if (currency == null) {
				            	return dataValues;
				            }
				            
				            if (seller.equals(EMU_BANK) && currency.equals(AUD_CURRENCY) ||
				            	seller.equals(BISON_BANK) && currency.equals(USD_CURRENCY)) {
				            	
				            	expression = PREMIUM_AMOUNT;
					            
					            nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODE);
					            
					            if (nodeList.getLength() > 0) {

						            nNode = nodeList.item(0);

						            String amount = nNode.getNodeValue();
						            
						            if (amount == null) {
						            	return dataValues;
						            }
						            
						            dataValues.add(buyer);
						            dataValues.add(seller);
						            dataValues.add(amount);
						            dataValues.add(currency);
					            }
				            }
						}
		            }
				}
			}
			
		} catch (Exception e) {
			LOG.error("Failed to parse data file: ["+e.getMessage()+"]");
		}
		
		return dataValues;
	}
	
	/**
	 * <p>Checks if two strings are anagrams of each other.
	 * </p>
	 * @param str1 first string
	 * @param str2 second string
	 * @return boolean true/false
	 */
	private boolean areAnagrams(String str1, String str2) {
		
		if (str1 == null || str2 == null) {
			return false;
		}
		
		char[] word1 = str1.toCharArray();
		char[] word2 = str2.toCharArray();
		
		Arrays.sort(word1);
		Arrays.sort(word2);
		
		return String.valueOf(word1).equalsIgnoreCase(String.valueOf(word2));
	}
}
