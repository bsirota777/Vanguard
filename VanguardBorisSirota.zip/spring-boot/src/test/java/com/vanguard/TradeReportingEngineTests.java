package com.vanguard;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.vanguard.creator.OutputCreator;
import com.vanguard.parsers.FileParser;

@SpringBootTest
class TradeReportingEngineTests {

	@Autowired
	private FileParser fileParser;
	
	@Autowired
	private OutputCreator outputCreator;

	@Test
	void parseNullDirectory() {
		assertEquals(fileParser.parse(null).size(),0);
	}
	
	@Test
	void parseBlankDirectory() {
		assertEquals(fileParser.parse("").size(),0);
	}
	
	@Test
	void generateCSVFileNullData() {
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    final String utf8 = StandardCharsets.UTF_8.name();
		try (PrintStream printStream =  new PrintStream(baos, true, utf8)) {
			outputCreator.generate(null, printStream);
			
			String data = baos.toString(utf8);
			
			assertEquals(data.substring(0, "buyer_party,seller_party,premium_amount,premium_currency".length()),
					     "buyer_party,seller_party,premium_amount,premium_currency");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void generateCSVFileNoData() {
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    final String utf8 = StandardCharsets.UTF_8.name();
		try (PrintStream printStream =  new PrintStream(baos, true, utf8)) {
			
			List<List<String>> outputList = new ArrayList<List<String>>();
			
			outputCreator.generate(outputList, printStream);
			
			String data = baos.toString(utf8);
			
			assertEquals(data.substring(0, "buyer_party,seller_party,premium_amount,premium_currency".length()),
					     "buyer_party,seller_party,premium_amount,premium_currency");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void generateCSVFileWithData() {
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    final String utf8 = StandardCharsets.UTF_8.name();
		try (PrintStream printStream =  new PrintStream(baos, true, utf8)) {
			
			List<List<String>> outputList = new ArrayList<List<String>>();
			List<String> row = new ArrayList<String>();
			row.add("EMU_BANK");
			row.add("ROO_BANK");
			row.add("0");
			row.add("AUD");
			outputList.add(row);
			
			outputCreator.generate(outputList, printStream);
			
			String data = baos.toString(utf8);
			System.out.println(data);
			assertEquals(data.indexOf("EMU_BANK,ROO_BANK,0,AUD"),
					     "buyer_party,seller_party,premium_amount,premium_currency".length()+2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
